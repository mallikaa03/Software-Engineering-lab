var searchData=
[
  ['getgrade_0',['getGrade',['../class_student.html#a46f8c147a252e6a3d642d9b54d62b90d',1,'Student']]],
  ['getname_1',['getName',['../class_student.html#af2b671e64af8a240f59652414a8b8047',1,'Student']]]
];
