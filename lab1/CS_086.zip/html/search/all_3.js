var searchData=
[
  ['now_0',['now',['../class_time.html#a4e698154700835119a946be6071a0984',1,'Time']]]
];
