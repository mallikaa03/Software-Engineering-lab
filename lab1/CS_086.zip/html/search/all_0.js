var searchData=
[
  ['area_0',['area',['../class_shape.html#afeee6df3afb921a347db5faa1349af4d',1,'Shape']]]
];
