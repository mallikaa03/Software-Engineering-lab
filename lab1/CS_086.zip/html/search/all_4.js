var searchData=
[
  ['sample_2eh_0',['sample.h',['../sample_8h.html',1,'']]],
  ['setgrade_1',['setGrade',['../class_student.html#a9547c17d28385d164335384622218551',1,'Student']]],
  ['setname_2',['setName',['../class_student.html#af289cfb2ae8a57077bd91062b9769719',1,'Student']]],
  ['shape_3',['Shape',['../class_shape.html',1,'']]],
  ['student_4',['Student',['../class_student.html',1,'Student'],['../class_student.html#ab11203c5f5572370344d9440a444c823',1,'Student::Student()']]]
];
